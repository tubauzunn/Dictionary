import XCTest
@testable import FinalHomework

class DetailPresenterTests: XCTestCase {
    
    var presenter: DetailPresenter!
    var mockView: MockDetailView!
    var mockInteractor: MockDetailInteractor!
    
    override func setUpWithError() throws {
        super.setUp()
        mockView = MockDetailView()
        mockInteractor = MockDetailInteractor()
        presenter = DetailPresenter(word: "example")
        presenter.view = mockView
        presenter.interactor = mockInteractor
    }
    
    override func tearDownWithError() throws {
        presenter = nil
        mockView = nil
        mockInteractor = nil
        super.tearDown()
    }
    
    func testViewDidLoadCallsFetchMethods() {
        
        presenter.viewDidLoad()
        
       
        XCTAssertTrue(mockInteractor.fetchWordDetailsCalled)
        XCTAssertTrue(mockInteractor.fetchSynonymsCalled)
    }
    
    func testDidFetchWordDetails() {
        
        let mockDetails = WordDetails(word: "example", phonetic: "ɪɡˈzɑːmpəl", meanings: [], synonyms: ["illustration", "instance", "exemplification"], noun: "example", adjective: "exemplary", phonetics: [Phonetic(text: "ɪɡˈzɑːmpəl", audio: "https://example.com/audio.mp3")])
        
       
        presenter.didFetchWordDetails(mockDetails)
        
       
        XCTAssertTrue(mockView.displayWordDetailsCalled)
        
    }
    
    func testDidFetchSynonyms() {
       
        let mockSynonyms = ["illustration", "instance", "exemplification"]
        
        
        presenter.didFetchSynonyms(mockSynonyms)
        
        
        XCTAssertTrue(mockView.displaySynonymsCalled)
        XCTAssertEqual(mockView.displayedSynonyms, mockSynonyms)
    }
    
    func testDisplayError() {
        
        let error = "An error occurred"
        
        
        presenter.didFailToFetchDetails(with: error)
        
       
        XCTAssertTrue(mockView.displayErrorCalled)
        XCTAssertEqual(mockView.displayedError, error)
    }
    
    func testPlayAudio() {
        
        let mockDetails = WordDetails(word: "example", phonetic: "ɪɡˈzɑːmpəl", meanings: [], synonyms: ["illustration", "instance", "exemplification"], noun: "example", adjective: "exemplary", phonetics: [Phonetic(text: "ɪɡˈzɑːmpəl", audio: "https://example.com/audio.mp3")])
        presenter.didFetchWordDetails(mockDetails)
        
       
        
        
        
        XCTAssertNotNil(mockView.playAudioCalled)
        XCTAssertEqual(mockView.playedAudioURL, "https://example.com/audio.mp3")
    }
    
    func testViewDidLoadWithError() {
        
        mockInteractor.shouldFailOnFetch = true
        
        
        presenter.viewDidLoad()
        
       
        XCTAssertTrue(mockView.displayErrorCalled)
        XCTAssertEqual(mockView.displayedError, "Failed to fetch details")
    }
    
    func testViewDidLoadWithEmptySynonyms() {
        
        let mockDetails = WordDetails(word: "example", phonetic: "ɪɡˈzɑːmpəl", meanings: [], synonyms: [], noun: "example", adjective: "exemplary", phonetics: [])
        
       
        presenter.didFetchWordDetails(mockDetails)
        
        
        XCTAssertTrue(mockView.displaySynonymsCalled)
        XCTAssertEqual(mockView.displayedSynonyms, [])
    }
}



class MockDetailView: DetailViewProtocol {
    var displayWordDetailsCalled = false
    var displayedWordDetails: WordDetails?
    var displaySynonymsCalled = false
    var displayedSynonyms: [String]?
    var displayErrorCalled = false
    var displayedError: String?
    var playAudioCalled = false
    var playedAudioURL: String?
    
    func displayWordDetails(_ details: WordDetails) {
        displayWordDetailsCalled = true
        displayedWordDetails = details
    }
    
    func displaySynonyms(_ synonyms: [String]) {
        displaySynonymsCalled = true
        displayedSynonyms = synonyms
    }
    
    func displayError(_ error: String) {
        displayErrorCalled = true
        displayedError = error
    }
    
    func playAudio(from url: String) {
        playAudioCalled = true
        playedAudioURL = url
    }
}

class MockDetailInteractor: DetailInteractorProtocol {
    weak var presenter: DetailPresenterProtocol?
    var fetchWordDetailsCalled = false
    var fetchSynonymsCalled = false
    var shouldFailOnFetch = false
    
    func fetchWordDetails(for word: String) {
        fetchWordDetailsCalled = true
        
        if shouldFailOnFetch {
            presenter?.didFailToFetchDetails(with: "Failed to fetch details")
        } else {
            let mockDetails = WordDetails(word: "example", phonetic: "ɪɡˈzɑːmpəl", meanings: [], synonyms: ["illustration", "instance", "exemplification"], noun: "example", adjective: "exemplary", phonetics: [Phonetic(text: "ɪɡˈzɑːmpəl", audio: "https://example.com/audio.mp3")])
            presenter?.didFetchWordDetails(mockDetails)
        }
    }
    
    func fetchSynonyms(for word: String) {
        fetchSynonymsCalled = true
        
        let mockSynonyms = ["illustration", "instance", "exemplification"]
        presenter?.didFetchSynonyms(mockSynonyms)
    }
}
