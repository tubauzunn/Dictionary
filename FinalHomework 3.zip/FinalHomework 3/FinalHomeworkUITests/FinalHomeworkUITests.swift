import XCTest

class DetailViewControllerUITests: XCTestCase {

    var app: XCUIApplication!

    override func setUpWithError() throws {
        continueAfterFailure = false
        app = XCUIApplication()
        app.launch()
    }

    override func tearDownWithError() throws {
        app = nil
    }

    func testDisplayWordDetails() throws {
        let exampleWord = "example"
        
        
        let wordField = app.textFields["wordField"]
        wordField.tap()
        wordField.typeText(exampleWord)
        app.buttons["searchButton"].tap()
        
        
        let wordLabel = app.staticTexts["wordLabel"]
        XCTAssertTrue(wordLabel.waitForExistence(timeout: 5))
        XCTAssertEqual(wordLabel.label, exampleWord.uppercased())
        
        let phoneticLabel = app.staticTexts["phoneticLabel"]
        XCTAssertTrue(phoneticLabel.exists)
        XCTAssertNotNil(phoneticLabel.label)
        
        
        let synonymsLabel = app.staticTexts["synonymsLabel"]
        XCTAssertTrue(synonymsLabel.exists)
        XCTAssertNotNil(synonymsLabel.label)
    }

    func testPlayAudio() throws {
        let exampleWord = "example"
        
        
        let wordField = app.textFields["wordField"]
        wordField.tap()
        wordField.typeText(exampleWord)
        app.buttons["searchButton"].tap()
        
        
        let audioButton = app.buttons["audioButton"]
        XCTAssertTrue(audioButton.waitForExistence(timeout: 5))
        audioButton.tap()
        
        let audioPlayer = app.otherElements["audioPlayer"]
        XCTAssertTrue(audioPlayer.waitForExistence(timeout: 5))
    }

    func testDisplayError() throws {
        let invalidWord = "invalidword"
        
        
        let wordField = app.textFields["wordField"]
        wordField.tap()
        wordField.typeText(invalidWord)
        app.buttons["searchButton"].tap()
        
        
        let errorAlert = app.alerts["Error"]
        XCTAssertTrue(errorAlert.waitForExistence(timeout: 5))
        XCTAssertEqual(errorAlert.staticTexts.element.label, "No details found for the word.")
    }

    func testExpandAndCollapseDefinitionSection() throws {
        let exampleWord = "example"
        
        
        let wordField = app.textFields["wordField"]
        wordField.tap()
        wordField.typeText(exampleWord)
        app.buttons["searchButton"].tap()
        
        
        let nounHeader = app.tables.staticTexts["Noun"]
        XCTAssertTrue(nounHeader.exists)
        nounHeader.tap()
        
        let definitionCell = app.tables.cells.staticTexts["definitionCell"]
        XCTAssertTrue(definitionCell.exists)
        XCTAssertTrue(definitionCell.isHittable)
    }
}
