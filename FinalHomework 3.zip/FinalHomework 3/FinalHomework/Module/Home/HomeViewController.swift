import UIKit

protocol HomeViewProtocol: AnyObject {
    func displayRecentSearches(_ searches: [String])
}

final class HomeViewController: UIViewController, HomeViewProtocol {
    var presenter: HomePresenterProtocol?
    private var recentSearches: [String] = []
    private let maxRecentSearches = 5

    let searchTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Search"
        textField.borderStyle = .roundedRect
        textField.translatesAutoresizingMaskIntoConstraints = false
        return textField
    }()

    lazy var searchButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Search", for: .normal)
        button.backgroundColor = .blue
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 5
        button.layer.masksToBounds = true
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self, action: #selector(searchButtonTapped(_:)), for: .touchUpInside)
        return button
    }()

    let recentSearchesLabel: UILabel = {
        let label = UILabel()
        label.text = "Recent Search"
        label.font = UIFont.boldSystemFont(ofSize: 18)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.isHidden = true
        return label
    }()

    let recentSearchesTableView: UITableView = {
        let tableView = UITableView()
        tableView.translatesAutoresizingMaskIntoConstraints = false
        return tableView
    }()

    var searchButtonBottomConstraint: NSLayoutConstraint!

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        presenter?.viewDidLoad()
        recentSearchesTableView.dataSource = self
        recentSearchesTableView.delegate = self

        recentSearchesTableView.register(UITableViewCell.self, forCellReuseIdentifier: "RecentSearchCell")

        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        view.addGestureRecognizer(tapGesture)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        searchTextField.text = "" 
    }

    func setupUI() {
        view.backgroundColor = .white
        view.addSubview(searchTextField)
        view.addSubview(searchButton)
        view.addSubview(recentSearchesLabel)
        view.addSubview(recentSearchesTableView)

        NSLayoutConstraint.activate([
            searchTextField.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            searchTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            searchTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            searchTextField.heightAnchor.constraint(equalToConstant: 40),

            recentSearchesLabel.topAnchor.constraint(equalTo: searchTextField.bottomAnchor, constant: 20),
            recentSearchesLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),

            recentSearchesTableView.topAnchor.constraint(equalTo: recentSearchesLabel.bottomAnchor, constant: 10),
            recentSearchesTableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            recentSearchesTableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            recentSearchesTableView.bottomAnchor.constraint(equalTo: searchButton.topAnchor, constant: -10),

            searchButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            searchButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            searchButton.heightAnchor.constraint(equalToConstant: 50),
        ])

        searchButtonBottomConstraint = searchButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        searchButtonBottomConstraint.isActive = true
    }

    @objc func searchButtonTapped(_ sender: UIButton) {
        if let searchText = searchTextField.text, !searchText.isEmpty {
            presenter?.searchButtonTapped(with: searchText)
            updateRecentSearches(with: searchText)
            recentSearchesLabel.isHidden = false
        }
    }

    private func updateRecentSearches(with searchText: String) {
        recentSearches.insert(searchText, at: 0)

        if recentSearches.count > maxRecentSearches {
            recentSearches.removeLast()
        }

        recentSearchesTableView.reloadData()
    }

    func displayRecentSearches(_ searches: [String]) {
        DispatchQueue.main.async { [weak self] in
            self?.recentSearches = searches.filter { !$0.starts(with: "Search") }
            self?.recentSearchesTableView.reloadData()
            self?.recentSearchesLabel.isHidden = self?.recentSearches.isEmpty ?? true
        }
    }

    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
            let keyboardHeight = keyboardSize.height
            searchButtonBottomConstraint.constant = -keyboardHeight - 10
            view.layoutIfNeeded()
        }
    }

    @objc func keyboardWillHide(notification: NSNotification) {
        searchButtonBottomConstraint.constant = -20
        view.layoutIfNeeded()
    }

    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
}


extension HomeViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return recentSearches.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "RecentSearchCell", for: indexPath)
        cell.textLabel?.text = recentSearches[indexPath.row]
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        presenter?.didSelectRecentSearch(recentSearches[indexPath.row])
    }
}
